// Function to load particles with a given color
function loadParticles(color) {
    particlesJS("particles-js", {
        "particles": {
            "number": {
                "value": 80
            },
            "color": {
                "value": color
            },
            "shape": {
                "type": "circle"
            },
            "opacity": {
                "value": 0.5
            },
            "size": {
                "value": 3,
                "random": true
            },
            "line_linked": {
                "enable": true,
                "distance": 150,
                "color": color,
                "opacity": 0.4,
                "width": 1
            },
            "move": {
                "enable": true,
                "speed": 4,
                "direction": "none",
                "out_mode": "out"
            }
        },
        "retina_detect": true
    });
}

// Load initial particles (black for light theme)
loadParticles("#000000");

// Typing animation
const typingText = document.querySelector('.typing-text');
const phrases = ["Web Development", "UI/UX Design", "Frontend Magic"];
let currentPhrase = 0;
let charIndex = 0;
let typingDelay = 100;
let erasingDelay = 50;
let newTextDelay = 2000;

function type() {
    if (charIndex < phrases[currentPhrase].length) {
        typingText.textContent += phrases[currentPhrase].charAt(charIndex);
        charIndex++;
        setTimeout(type, typingDelay);
    } else {
        setTimeout(erase, newTextDelay);
    }
}

function erase() {
    if (charIndex > 0) {
        typingText.textContent = phrases[currentPhrase].substring(0, charIndex - 1);
        charIndex--;
        setTimeout(erase, erasingDelay);
    } else {
        currentPhrase = (currentPhrase + 1) % phrases.length;
        setTimeout(type, typingDelay + 300);
    }
}

document.addEventListener("DOMContentLoaded", () => {
    if (phrases.length) setTimeout(type, newTextDelay + 250);
});

// Smooth scroll and active link
document.querySelectorAll("nav a").forEach(link => {
    link.addEventListener("click", function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute("href")).scrollIntoView({
            behavior: "smooth"
        });
        document.querySelectorAll("nav a").forEach(a => a.classList.remove("active"));
        this.classList.add("active");
        document.getElementById("nav-links").classList.remove("show");
    });
});

// Theme toggle + dynamic particle color change
const themeToggle = document.getElementById("theme-toggle");

themeToggle.addEventListener("click", () => {
    document.body.classList.toggle("dark-theme");

    // Destroy existing particles instance before reloading
    if (window.pJSDom && window.pJSDom.length) {
        window.pJSDom[0].pJS.fn.vendors.destroypJS();
        window.pJSDom = [];
    }

    // Load particles based on theme
    const particleColor = document.body.classList.contains("dark-theme") ? "#ffffff" : "#000000";
    loadParticles(particleColor);

    // Optional: Toggle button icon or text
    themeToggle.textContent = document.body.classList.contains("dark-theme") ? "☀️" : "🌙";
});

// Hamburger menu toggle
document.getElementById("menu-toggle").addEventListener("click", () => {
    document.getElementById("nav-links").classList.toggle("show");
});

function animateOnScroll() {
    const aboutText = document.querySelector('.about-text');
    const aboutImage = document.querySelector('.about-image');
    const triggerPoint = window.innerHeight * 0.8;

    if (aboutText && aboutImage) {
        const textTop = aboutText.getBoundingClientRect().top;
        if (textTop < triggerPoint) {
            aboutText.style.opacity = '1';
            aboutText.style.transform = 'translateX(0)';
            aboutImage.style.opacity = '1';
            aboutImage.style.transform = 'translateX(0)';
        }
    }
}
document.querySelectorAll(".bar").forEach((bar) => {
    bar.addEventListener("mouseenter", () => {
        const percent = bar.getAttribute("data-percent");
        bar.querySelector("span").style.width = percent;
    });

    bar.addEventListener("mouseleave", () => {
        bar.querySelector("span").style.width = "0";
    });
});
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener("click", function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute("href"));
        target.scrollIntoView({
            behavior: "smooth"
        });
    });
});

window.addEventListener('scroll', animateOnScroll);
window.addEventListener('load', animateOnScroll);